﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Medical
{
    public partial class SellMenu : Form
    {
        public static string c_id = "";
        /*public static string c_name = "";
        public static string c_phoneno = "";
        public static string  medid = "";
        public static string sold_stock = "";
        public static string total_price= "";
         * */
        public SellMenu()
        {
            InitializeComponent();
            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void SellMenu_Load(object sender, EventArgs e)
        {
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;
            button1.Visible = false;
            textBox6.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            textBox7.Visible = false;
            textBox8.Visible = false;
            label9.Visible = false;
            textBox9.Visible = false;
            //button2.Visible = false;
            //button3.Visible = false;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            label1.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            button1.Visible = true;
            textBox6.Visible = true;
            label6.Visible = true;
            label7.Visible = true;
            label8.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            label9.Visible = true;
            textBox9.Visible = true;
            button2.Visible = false;
            button3.Visible = false;
            //button4.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection sc1 = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\admin\\Desktop\\Medical\\Medical\\MIS.mdf;Integrated Security=True;User Instance=True");
            SqlCommand com1 = new SqlCommand("SELECT comp_med_id from Company where comp_med_id='"+textBox4.Text.ToString()+"'", sc1);
            sc1.Open();
            SqlDataAdapter sda = new SqlDataAdapter(com1);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("MedId not available");
            }
          
            else
            {
                SqlConnection sc2 = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\admin\\Desktop\\Medical\\Medical\\MIS.mdf;Integrated Security=True;User Instance=True");
                SqlCommand com2 = new SqlCommand("SELECT med_id from Customer where med_id='" + textBox4.Text.ToString() + "'", sc1);
                sc2.Open();
                SqlDataAdapter sda1 = new SqlDataAdapter(com2);
                DataTable dt1 = new DataTable();
                sda1.Fill(dt1);
                if (dt1.Rows.Count > 0)
                {
                    MessageBox.Show("Med Id already exist in cutomer table");
                }
                if(dt1.Rows.Count == 0)
                {


                    try
                    {

                        SqlConnection sc = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\admin\\Desktop\\Medical\\Medical\\MIS.mdf;Integrated Security=True;User Instance=True");
                        SqlCommand com = new SqlCommand("INSERT into Customer (c_id,c_name,c_phoneno,med_id,sold_stock,total_price,total_stock,stock_left,med_price) values ('" + textBox1.Text.ToString() + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text.ToString() + "','" + textBox5.Text.ToString() + "','" + textBox6.Text.ToString() + "','" + textBox7.Text.ToString() + "','" + textBox8.Text.ToString() + "','" + textBox9.Text.ToString() + "') ", sc);
                        sc.Open();
                        com.ExecuteNonQuery();
                        MessageBox.Show("Inserted");
                        DisplayData();
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("CId exist");
                    }

                }
            }
        }
        public void DisplayData()
        {
            SqlConnection sc = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\admin\\Desktop\\Medical\\Medical\\MIS.mdf;Integrated Security=True;User Instance=True");
            SqlCommand com = new SqlCommand("SELECT * from Customer", sc);
            sc.Open();
            SqlDataAdapter sda = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;
            button1.Visible = false;
            textBox6.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            textBox7.Visible = false;
            textBox8.Visible = false;
            DisplayData();
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            label1.Visible = true;
            textBox1.Visible = true;
            button2.Visible = true;
            button1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            //textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;
            label6.Visible = false;
            button3.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            textBox7.Visible = false;
            textBox8.Visible = false;
            label9.Visible = false;
            textBox9.Visible = false;

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection sc = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\admin\\Desktop\\Medical\\Medical\\MIS.mdf;Integrated Security=True;User Instance=True");
            SqlCommand com = new SqlCommand("DELETE Customer where c_id='" + textBox1.Text + "' ", sc);
            sc.Open();
            //com.ExecuteNonQuery();
            SqlDataAdapter sda = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            MessageBox.Show("Deleted");
            DisplayData();
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            textBox6.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            textBox7.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
            textBox8.Text = dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
            textBox9.Text = dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString();

        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            label1.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            button1.Visible = false;
            textBox6.Visible = true;
            label6.Visible = true;
            button2.Visible = false;
            button3.Visible = true;
            label7.Visible = true;
            label8.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            label9.Visible = true;
            textBox9.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection sc = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\admin\\Desktop\\Medical\\Medical\\MIS.mdf;Integrated Security=True;User Instance=True");
            SqlCommand com = new SqlCommand("UPDATE Customer SET c_name='" + textBox2.Text + "',c_phoneno ='" + textBox3.Text.ToString() + "',med_id='" + textBox4.Text.ToString() + "',sold_stock='" + textBox5.Text.ToString()+"',total_price='"+textBox6.Text.ToString()+"',med_price='"+textBox9.Text.ToString()+"'  where c_id='" + textBox1.Text + "'", sc);
            sc.Open();
            //com.ExecuteNonQuery();
            SqlDataAdapter sda = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            MessageBox.Show("Updated");
            DisplayData();
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            label1.Visible = true;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            textBox1.Visible = true;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;
            button1.Visible = false;
            textBox6.Visible = false;
            label6.Visible = false;
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            textBox7.Visible = false;
            textBox8.Visible = false;
            label9.Visible = false;
            textBox9.Visible = false;


            
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            dataGridView1.DataSource = this.Search();
        }
         private DataTable Search()
        {
            string query = "SELECT * FROM Customer";
            query += " WHERE c_id LIKE '%' + @CustomerId + '%'";
            //query += " OR LastName LIKE '%' + @LastName + '%'";
            //query += " OR @FirstName = ''";
            string constr = "Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\admin\\Desktop\\Medical\\Medical\\MIS.mdf;Integrated Security=True;User Instance=True";
            SqlConnection con = new SqlConnection(constr);
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@CustomerId", textBox1.Text.Trim());
           // cmd.Parameters.AddWithValue("@LastName", textBox1.Text.Trim());
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            return dt;
        }

         private void button4_Click(object sender, EventArgs e)
         {
             c_id = textBox1.Text.ToString();
             //c_name = textBox2.Text;
             //c_phoneno = textBox3.Text.ToString();
             //medid = textBox4.Text.ToString();
             //sold_stock = textBox5.Text.ToString();
             //total_price = textBox6.Text.ToString();
             Bill b = new Bill();
             b.Show();
         }

         private void textBox5_KeyUp(object sender, KeyEventArgs e)
         {
             try
             {
                 SqlConnection sc1 = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\admin\\Desktop\\Medical\\Medical\\MIS.mdf;Integrated Security=True;User Instance=True");
                 SqlCommand com1 = new SqlCommand("SELECT med_stock,med_price from Company where comp_med_id='" + textBox4.Text.ToString() + "'", sc1);
                 sc1.Open();
                 SqlDataReader sdr = com1.ExecuteReader();
                 sdr.Read();
                 textBox7.Text = sdr["med_stock"].ToString();
                 textBox9.Text = sdr["med_price"].ToString();
                 textBox8.Text = (int.Parse(textBox7.Text) - int.Parse(textBox5.Text)).ToString();
                 textBox6.Text = (float.Parse(textBox9.Text) * float.Parse(textBox5.Text)).ToString();
                 
                
             }
             catch (Exception )
             {
                 if (textBox5.Text == "")
                 {
                     MessageBox.Show("Empty");
                 }
                 else
                 {
                     MessageBox.Show("Med Id is not available");
                 }
             }
             
           
         }

         private void textBox4_KeyUp(object sender, KeyEventArgs e)
         {
             SqlConnection sc1 = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\admin\\Desktop\\Medical\\Medical\\MIS.mdf;Integrated Security=True;User Instance=True");
             SqlCommand com1 = new SqlCommand("SELECT med_id from Customer where med_id='" + textBox4.Text.ToString() + "'", sc1);
             sc1.Open();
             SqlDataAdapter sda = new SqlDataAdapter(com1);
             DataTable dt = new DataTable();
             sda.Fill(dt);
             if (dt.Rows.Count > 0)
             {
                 MessageBox.Show("Med Id already exist in cutomer table");
             }
         }
        /* public void alreadyExist()
         {
             SqlConnection sc1 = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\admin\\Desktop\\Medical\\Medical\\MIS.mdf;Integrated Security=True;User Instance=True");
             SqlCommand com1 = new SqlCommand("SELECT med_id from Customer where med_id='" + textBox4.Text.ToString() + "'", sc1);
             sc1.Open();
             SqlDataAdapter sda = new SqlDataAdapter(com1);
             DataTable dt = new DataTable();
             sda.Fill(dt);
             if (dt.Rows.Count > 0)
             {
                 MessageBox.Show("Med Id already exist in cutomer table");
             }
         * 
         }*/
         
    
    }
}
